# TeamOne Server

## Installation:

**Step 1:** Log in to docker. 
```
docker login --username succeedium --password <your-access-token> ghcr.io
```

**Step 2:** Paste your SSL certificate into the `teamone.crt` and `teamone.key` files inside the `nginx/cert` directory.

**Step 3:** Build the server using docker-compose.
```
docker-compose build
```

**Step 4:** Run the server using docker-compose.
```
docker-compose up -d
```

## Update the server:

**1.** Log in to docker.
```
docker login --username succeedium --password <your-access-token> ghcr.io
```

**2.** Run docker-compose down.
```
docker-compose down
```

**3.** Pull the latest server image.
```
docker pull ghcr.io/succeedium/teamone-server-image:latest
```

**4.** Run docker-compose up.
```
docker-compose up -d
```
